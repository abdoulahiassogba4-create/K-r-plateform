# KËR — plateforme vidéo web

KËR est une base de projet full-stack pensée pour devenir un vrai site vidéo puis, plus tard, une application Android/iOS.

## Structure
- `public/` : interface web
- `src/index.js` : API Worker
- `migrations/001_init.sql` : schéma D1
- `wrangler.toml` : configuration Cloudflare Workers
- `.dev.vars.example` : variables locales

## Lancer localement
1. Installer Node.js.
2. Dans ce dossier : `npm install`
3. `npx wrangler dev`
4. Ouvrir l'adresse locale affichée.

## Déployer
`npx wrangler deploy`

Avant une vraie mise en production, crée la base D1 et le bucket R2 puis renseigne leurs IDs dans `wrangler.toml`.

## État
Cette livraison est une fondation complète et fonctionnelle du site : interface KËR, navigation, recherche, vidéos de démonstration, API, schéma de données, authentification de démonstration et préparation D1/R2. Le stockage vidéo réel et l'authentification de production doivent être configurés avec les ressources Cloudflare du propriétaire du projet.
