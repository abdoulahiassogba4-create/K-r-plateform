const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8" }
});

const demoVideos = [
  {id:"v1", title:"Bienvenue sur KËR", creator:"KËR Officiel", category:"Découverte", views:12840, duration:"2:18", thumbnail:"https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=900&q=80"},
  {id:"v2", title:"Les talents du Sénégal", creator:"Teranga Créative", category:"Sénégal", views:8420, duration:"8:42", thumbnail:"https://images.unsplash.com/photo-1523731407965-2430cd12f5e4?auto=format&fit=crop&w=900&q=80"},
  {id:"v3", title:"Football : les meilleurs moments", creator:"KËR Sport", category:"Sport", views:19400, duration:"6:12", thumbnail:"https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=900&q=80"},
  {id:"v4", title:"Créer sa première vidéo", creator:"KËR Academy", category:"Éducation", views:5310, duration:"11:03", thumbnail:"https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=900&q=80"},
  {id:"v5", title:"Gaming & communauté", creator:"KËR Gaming", category:"Gaming", views:11200, duration:"14:20", thumbnail:"https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=900&q=80"},
  {id:"v6", title:"Manga & Anime : découvertes", creator:"KËR Manga", category:"Manga & Anime", views:7610, duration:"9:31", thumbnail:"https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=900&q=80"}
];

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      if (url.pathname === "/api/health") return json({ok:true, service:"KËR API"});
      if (url.pathname === "/api/videos") {
        const q = (url.searchParams.get("q") || "").toLowerCase();
        const category = url.searchParams.get("category");
        let items = demoVideos.filter(v =>
          (!q || `${v.title} ${v.creator} ${v.category}`.toLowerCase().includes(q)) &&
          (!category || v.category === category)
        );
        return json({items});
      }
      if (url.pathname === "/api/categories") {
        return json({items:["Sénégal","Afrique","Sport","Musique","Gaming","Manga & Anime","Éducation","Cuisine","Voyage","Humour","Technologie"]});
      }
      return json({error:"Route API inconnue"},404);
    }
    return env.ASSETS.fetch(request);
  }
};
