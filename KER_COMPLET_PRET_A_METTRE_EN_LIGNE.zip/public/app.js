const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let videos=[], activeCategory="";
const categories=["Tous","Sénégal","Afrique","Sport","Musique","Gaming","Manga & Anime","Éducation","Cuisine","Voyage","Humour","Technologie"];

function card(v){return `<article class="card" data-id="${v.id}"><div class="thumb"><img src="${v.thumbnail}" alt=""><span class="duration">${v.duration}</span></div><h3>${v.title}</h3><p>${v.creator} · ${Number(v.views).toLocaleString("fr-FR")} vues</p></article>`}
function render(items=videos){$("#videoGrid").innerHTML=items.map(card).join("");$("#exploreGrid").innerHTML=items.slice().reverse().map(card).join("");$("#resultCount").textContent=`${items.length} vidéos`;$$(".card").forEach(x=>x.onclick=()=>openVideo(videos.find(v=>v.id===x.dataset.id)))}
function chips(){ $("#chips").innerHTML=categories.map(c=>`<button class="chip ${c==="Tous"?"active":""}" data-cat="${c}">${c}</button>`).join("");$$(".chip").forEach(b=>b.onclick=()=>{activeCategory=b.dataset.cat==="Tous"?"":b.dataset.cat;$$(".chip").forEach(x=>x.classList.remove("active"));b.classList.add("active");apply()})}
function apply(){const q=$("#search").value.trim().toLowerCase();const list=videos.filter(v=>(!activeCategory||v.category===activeCategory)&&(!q||`${v.title} ${v.creator} ${v.category}`.toLowerCase().includes(q)));render(list)}
function navigate(id){$$(".page").forEach(p=>p.classList.remove("active"));$("#"+id)?.classList.add("active");$$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.page===id));window.scrollTo({top:0,behavior:"smooth"})}
async function load(){try{const r=await fetch("/api/videos");const d=await r.json();videos=d.items||[]}catch(e){videos=[]}chips();render();categoryView();shortsView()}
function categoryView(){const icons=["🇸🇳","🌍","⚽","🎵","🎮","📖","📚","🍲","✈️","😂","💻"];$("#categoryGrid").innerHTML=categories.slice(1).map((c,i)=>`<div class="category" data-cat2="${c}"><b>${icons[i]}</b><h3>${c}</h3></div>`).join("");$$(".category").forEach(c=>c.onclick=()=>{activeCategory=c.dataset.cat2;navigate("home");$$(".chip").forEach(x=>x.classList.toggle("active",x.dataset.cat===activeCategory));apply()})}
function shortsView(){const s=[...videos,...videos];$("#shortGrid").innerHTML=s.slice(0,8).map(v=>`<article class="short" data-id="${v.id}"><img src="${v.thumbnail}" alt=""><span>▶ ${v.title}</span></article>`).join("");$$(".short").forEach(x=>x.onclick=()=>openVideo(videos.find(v=>v.id===x.dataset.id)))}
function openVideo(v){if(!v)return;$("#modalTitle").textContent=v.title;$("#modalMeta").textContent=`${v.creator} · ${Number(v.views).toLocaleString("fr-FR")} vues · ${v.category}`;$("#playerBox").innerHTML=`<div class="video-player"><div style="height:100%;display:grid;place-items:center;color:#aaa">▶ Lecteur KËR — vidéo de démonstration</div></div>`;$("#videoModal").classList.add("open")}
$$(".nav,[data-page]").forEach(b=>b.addEventListener("click",e=>{const p=e.currentTarget.dataset.page;if(p)navigate(p)}));
$("#searchBtn").onclick=()=>{navigate("home");apply()};$("#search").oninput=apply;
$("#createBtn").onclick=()=>navigate("studio");$("#uploadBtn").onclick=()=>$("#uploadModal").classList.add("open");
$("#loginBtn").onclick=()=>alert("Espace connexion KËR — à connecter à l'authentification de production.");
$$("[data-close]").forEach(b=>b.onclick=()=>b.closest(".modal").classList.remove("open"));
$("#publish").onclick=()=>{const f=$("#file").files[0];$("#uploadStatus").textContent=f?`« ${f.name} » est prêt. Le stockage R2 doit être connecté pour publier réellement en ligne.`:"Choisis une vidéo.";};
load();
